#include <iostream>
#define maximo 5
using namespace std;

struct Stack {
    int dado;
    int max;
    Stack *prox;
};

int pop(struct Stack * & topo){
 
	Stack * seguinte = topo;
			int val = seguinte -> dado;
  
			topo = seguinte->prox;
      cout << "\n"<< seguinte->dado << " Removido da pilha!\n";
			free(seguinte);
			return val;
		
  
}

void listar(Stack * & topo){
  if(topo == NULL){
		printf("\nPilha vazia\n");
	}

  else{
		printf("\nPilha Atual:\n");
			struct Stack * aux = topo;
			while(aux != NULL){
				printf("%d\n", aux->dado);
				aux = aux->prox;  
			}
	}
}

int quantidade(Stack * & topo){
Stack *temp = topo;
int qnt = 0;  
 while(temp != NULL){
   qnt++;
   temp=temp->prox;
 } 
  //printf("%d\n", qnt);

  return qnt;
}

void push(Stack * & topo, int dado){

  if(maximo <= 0){
  printf("Pilha sem espaços disponiveis!\n");
    } 
    
  else {    
    if(topo == NULL){ 
    
      Stack *pilha = NULL;
      pilha = (Stack*) calloc (1, sizeof(Stack));
      
      if(pilha == NULL){ 
     printf("ERRO DE ALOCAÇÂO!\n");
      } 
        
      else{  
      pilha->dado = dado;
      pilha->prox = NULL;
      topo = pilha;
      topo->max = quantidade(topo);
      cout << "\n\nValor " << dado << " Adicionado à pilha!\n";  
      return;
      }
   }
      
  else if(topo->max != maximo) { //verifica tamanho max da pilha 
     Stack *pilha = NULL;
      pilha = (Stack*) calloc (1, sizeof(Stack)); //aloca ponteiro
    
      if(pilha == NULL){ 
     printf("ERRO DE ALOCAÇÂO!\n");}//verifica falha na alocação
      else{
      pilha->dado = dado;
     pilha->prox = topo;
     topo = pilha;
     cout << "\nValor " << dado << " Adicionado à pilha!\n";   
   } //aloca elemento na pilha
   } //demais elementos da pilha
   }
    topo->max = quantidade(topo); // topo sempre terá qnt elementos na pilha  
  }

void Isfull_Isempty(Stack *& topo){
  if(topo == NULL){
    cout << "\nPilha Vazia!\n";
  }
  else if(topo->max == maximo){
    cout << "\n\nPilha cheia!\n\n";
  }

  else{
    cout << "\nPilha com " << maximo - topo->max << " espaços disponiveis\n";
    }
}

void consultar(Stack * topo, int c){
Stack * aux;
aux = topo;
int valor = c;
  
  if(topo == NULL){
    cout << "Pilha Vazia!\n";
    return;
  }
  else{
    while(aux != NULL){
    if (aux->dado == c){
      if(aux->max == 0){
        int p = 1;
      }
      printf("Valor encontrado no nivel %d\n", maximo - (aux->max+1));
      return;
    }
    else {
     aux = aux->prox; 
    } 
    }
  printf("Valor não encontrado na pilha!\n");
}
  }

int main() {
  Stack *topo = NULL;
  int tam;
  int dado;
  int qtd;

  
  Isfull_Isempty(topo);
  
 push(topo, 10);
 push(topo, 20);
 push(topo, 30);
 push(topo, 40);
 push(topo, 50);
 push(topo, 60);

  Isfull_Isempty(topo);
  
  listar(topo);
  qtd = quantidade(topo);
  cout << "\nQuantidade de elementos atuais na fila: " << qtd << "\n";  
  
 pop(topo);
 pop(topo);
 push(topo, 100);
    
  listar(topo);
  qtd = quantidade(topo);
  cout << "\nQuantidade de elementos atuais na fila: " << qtd << "\n\n";  

  consultar(topo, 10);
}